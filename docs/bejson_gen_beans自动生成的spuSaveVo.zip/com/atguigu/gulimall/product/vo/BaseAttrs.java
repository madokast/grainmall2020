/**
  * Copyright 2020 bejson.com 
  */
package com.atguigu.gulimall.product.vo;

/**
 * Auto-generated: 2020-06-02 22:24:14
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class BaseAttrs {

    private int attrId;
    private String attrValues;
    private int showDesc;
    public void setAttrId(int attrId) {
         this.attrId = attrId;
     }
     public int getAttrId() {
         return attrId;
     }

    public void setAttrValues(String attrValues) {
         this.attrValues = attrValues;
     }
     public String getAttrValues() {
         return attrValues;
     }

    public void setShowDesc(int showDesc) {
         this.showDesc = showDesc;
     }
     public int getShowDesc() {
         return showDesc;
     }

}