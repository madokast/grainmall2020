/**
  * Copyright 2020 bejson.com 
  */
package com.atguigu.gulimall.product.vo;

/**
 * Auto-generated: 2020-06-02 22:24:14
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Bounds {

    private int buyBounds;
    private int growBounds;
    public void setBuyBounds(int buyBounds) {
         this.buyBounds = buyBounds;
     }
     public int getBuyBounds() {
         return buyBounds;
     }

    public void setGrowBounds(int growBounds) {
         this.growBounds = growBounds;
     }
     public int getGrowBounds() {
         return growBounds;
     }

}