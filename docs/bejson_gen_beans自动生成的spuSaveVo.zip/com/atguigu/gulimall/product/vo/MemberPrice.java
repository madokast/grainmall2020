/**
  * Copyright 2020 bejson.com 
  */
package com.atguigu.gulimall.product.vo;

/**
 * Auto-generated: 2020-06-02 22:24:14
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class MemberPrice {

    private int id;
    private String name;
    private int price;
    public void setId(int id) {
         this.id = id;
     }
     public int getId() {
         return id;
     }

    public void setName(String name) {
         this.name = name;
     }
     public String getName() {
         return name;
     }

    public void setPrice(int price) {
         this.price = price;
     }
     public int getPrice() {
         return price;
     }

}